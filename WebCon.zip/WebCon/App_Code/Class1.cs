﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    public string cns2;

	public Class1()
	{
        cns2 = (@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Aakanksh T.Y\.net\WebCon\App_Data\dbBank.mdf;Integrated Security=True");
		//
		// TODO: Add constructor logic here
		//
	}
}