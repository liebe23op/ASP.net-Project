﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class frmBank : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;

    SqlDataAdapter da;
    DataSet ds;

    int n, c, i;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        Class1 c2 = new Class1();
        cn = new SqlConnection(c2.cns2);
        cn.Open();
        da = new SqlDataAdapter();
        ds = new DataSet();
        showData();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("update emp set emp_name=@emp_name,salary=@salary where emp_no=@emp_no", cn);
        cm.Parameters.AddWithValue("@emp_no", txtID.Text);
        cm.Parameters.AddWithValue("@emp_name", txtName .Text);
        cm.Parameters.AddWithValue("@salary", txtSal.Text);

        da.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("emp_no=" + int.Parse(txtID.Text)));
        drw[0][0] = int.Parse(txtID.Text);
        drw[0][1] = txtName.Text;
        drw[0][2] = float.Parse(txtSal.Text);


        da.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        Response.Write("<script> alert('Record Updated');</script>");
    }
    private void showData()
    {
        ds.Clear();
        cm = new SqlCommand("select * from Employee", cn);
        da.SelectCommand = cm;
        da.Fill(ds, "Employee");
        da.Update(ds.Tables[0]);
        ds.AcceptChanges();

        n = ds.Tables[0].Rows.Count;
        lblTEmp.Text = "Total Employees : " + n.ToString();
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
    }
    private void eachRec()
    {
        txtID.Text = ds.Tables[0].Rows[c].ItemArray[0].ToString();
        txtName.Text = ds.Tables[0].Rows[c].ItemArray[1].ToString();
        txtSal.Text = ds.Tables[0].Rows[c].ItemArray[2].ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("insert into Employee (Name,Salary) values(@Name,@Salary)", cn);
        cm.Parameters.AddWithValue("@Name", txtName.Text);
        cm.Parameters.AddWithValue("@Salary", txtSal.Text);
        da.InsertCommand = cm;
        DataRow drw = ds.Tables[0].NewRow();
        drw[1] = txtName.Text;
        drw[2] = float.Parse(txtSal.Text);
        ds.Tables[0].Rows.Add(drw);
        da.Fill(ds, "Employee");
        da.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
    }
    protected void btnDelAll_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("delete from  Employee  ", cn);
       

        da.DeleteCommand = cm;
       
        ds.Tables[0].Rows[0].Delete();


        da.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        Response.Write("<script> alert('Record Deleted');</script>");
    }
    protected void BubtnUpdate_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("update Employee set Name=@Name,Salary=@Salary where Id=@Id", cn);
        cm.Parameters.AddWithValue("@Id", txtID.Text);
        cm.Parameters.AddWithValue("@Name", txtName.Text);
        cm.Parameters.AddWithValue("@Salary", txtSal.Text);

        da.UpdateCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("Id=" + int.Parse(txtID.Text)));
        drw[0][0] = int.Parse(txtID.Text);
        drw[0][1] = txtName.Text;
        drw[0][2] = float.Parse(txtSal.Text);


        da.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        Response.Write("<script> alert('Record Updated');</script>");
    }
    protected void btnDel_Click(object sender, EventArgs e)
    {
        cm = new SqlCommand("delete from  Employee  where Id=@Id", cn);
        cm.Parameters.AddWithValue("@Id", txtID.Text);

        da.DeleteCommand = cm;
        DataRow[] drw = ds.Tables[0].Select(String.Format("Id=" + int.Parse(txtID.Text)));

        ds.Tables[0].Rows[0].Delete();


        da.Update(ds.Tables[0]);
        ds.AcceptChanges();
        showData();
        Response.Write("<script> alert('Record Deleted');</script>");
    }
}