﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class frmDisconnected : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        cn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Aakanksh T.Y\.net\WebTale\App_Data\dbWebTab.mdf;Integrated Security=True");
        cn.Open();
        da = new SqlDataAdapter();
        ds = new DataSet();
        showData();
    }
    protected void showData()
    {
        cm = new SqlCommand("select * from Emp", cn);
        da.SelectCommand = cm;
        da.Fill(ds, "Emp");
        da.Update(ds.Tables[0]);
        ds.AcceptChanges();

        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
    }
}